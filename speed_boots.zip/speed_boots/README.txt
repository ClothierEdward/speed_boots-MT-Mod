The Boots of Swiftness Mod (aka speed_boots)

Adds in a new item to allow the player to run very fast called the Boots of Swiftness.
============================================

This is where the copyright licenses would go but I don't fully understand how they work right now.

Notes:
This mod was made by ClothierEdward (aka u/ClothierCrafter on Reddit)

The mod icon is a screenshot which uses textures from Minetest Game.